"""Core modules for Doser"""
