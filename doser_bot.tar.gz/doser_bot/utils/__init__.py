"""Utility modules for Doser"""
