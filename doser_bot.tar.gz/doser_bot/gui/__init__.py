"""GUI modules for Doser"""
