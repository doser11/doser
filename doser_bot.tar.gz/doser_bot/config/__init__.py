"""Configuration for Doser"""
